﻿namespace dotNet5781_02_5713_9142
{
    public enum Area
    {
        GENERAL, NORTH, SOUTH, CENTER, JERUSALEM, NON
    }
}
