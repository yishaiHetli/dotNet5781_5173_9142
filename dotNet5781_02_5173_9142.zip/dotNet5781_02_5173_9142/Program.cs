﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dotNet5781_02_5713_9142
{
    class Program
    {
        static void Main(string[] args)
        {
            Station A = new Station();
            Console.WriteLine(A.ToString());
            Console.ReadKey();

        }
    }
}
